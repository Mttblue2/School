import java.util.Scanner;
import java.text.*;
import java.io.*;

public class Networking2
{
   public static void main(String[] args) throws IOException
   {
      double f = 1;
      double t = 0.00;
      String outputName = "warning.txt";
      
      FileWriter writeFile = new FileWriter("X-Y numbers");
      PrintWriter outFile = new PrintWriter(writeFile);
      DecimalFormat Formatter = new DecimalFormat("0.000000000000000");
      DecimalFormat Formatter2 = new DecimalFormat("0.00");
      
      outFile.println();
      outFile.println("Networking Assignment 2 Numbers");
      outFile.println();
      outFile.println("x                    y1                    y2                    y3                    " + 
                      "s1                    s2                    sqwave");
      
      //for(double t = 0.00; t == 2.00; t = t+.01)
      while (t <= 2.01)
      {
      
         double y1 = (4/Math.PI) * Math.sin (2 * Math.PI *1* f * t);
         double y2 = (4/3 * Math.PI) * Math.sin (2 * Math.PI *3* f * t);
         double y3 = (4/5 * Math.PI) * Math.sin (2 * Math.PI *5* f * t);
         
         double s1 = y2 + y1;
         double s2 = s1 + y3;
         
         double sqwave = Math.signum( Math.sin(2*Math.PI*f*t) );
    
         outFile.println(Formatter2.format(t) + "                 " + Formatter.format(y1) + "     " +
         Formatter.format(y2)  + "     " + Formatter.format(y3) + "     " + Formatter.format(s1)  + 
         "     " + Formatter.format(s2)  + "     " + Formatter.format(sqwave));
         t = t + .01;
      }
      outFile.close();
   }
}